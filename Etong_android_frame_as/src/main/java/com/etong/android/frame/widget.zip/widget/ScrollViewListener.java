package com.etong.android.frame.widget;

public interface ScrollViewListener {

	void onScrollChanged(CustomScrollView scrollView, int x, int y, int oldx, int oldy);

}
