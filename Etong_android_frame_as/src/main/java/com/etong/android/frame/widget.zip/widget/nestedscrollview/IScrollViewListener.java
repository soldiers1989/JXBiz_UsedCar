package com.etong.android.frame.widget.nestedscrollview;

/**
 * @desc (这里用一句话描述这个类的作用)
 * @createtime 2016/9/29 - 17:01
 * @Created by xiaoxue.
 */

public interface IScrollViewListener {

    void scrollViewListener(int l, int t, int oldL, int oldT);
}
