package com.etong.android.frame.widget.photoview;

/**
 * @author : by sunyao
 * @ClassName : Frame_OnRotateListener
 * @Description : (这里用一句话描述这个类的作用)
 * @date : 2016/10/11 - 18:34
 */

public interface Frame_OnRotateListener {
    void onRotate(float degrees, float focusX, float focusY);
}
